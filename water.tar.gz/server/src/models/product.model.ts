import { v4 as uuidv4 } from 'uuid';
import { getDb } from '../utils/db';
import type { Product } from '../types';

const db = getDb();

export const productModel = {
  create(data: Partial<Product>): Product {
    const id = `prod-${Date.now()}`;
    db.prepare(
      'INSERT INTO products (id, name, description, price, unit, image, stock, brand_id, status, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      id,
      data.name || '',
      data.description || '',
      data.price || 0,
      data.unit || '瓶',
      data.image || '',
      data.stock ?? 99999,
      data.brand_id || '',
      data.status || 'active',
      data.sort_order ?? 0
    );
    return this.findById(id)!;
  },

  findById(id: string): Product | undefined {
    const row = db.prepare('SELECT p.*, b.name as brand_name FROM products p LEFT JOIN brands b ON p.brand_id = b.id WHERE p.id = ?').get(id) as any;
    return row || undefined;
  },

  findAll(activeOnly = true, options?: { brandId?: string; keyword?: string }): Product[] {
    let sql = activeOnly
      ? 'SELECT p.*, b.name as brand_name FROM products p LEFT JOIN brands b ON p.brand_id = b.id WHERE p.status = ?'
      : 'SELECT p.*, b.name as brand_name FROM products p LEFT JOIN brands b ON p.brand_id = b.id WHERE 1=1';
    const params: any[] = [];
    if (activeOnly) {
      params.push('active');
    }
    if (options?.brandId) {
      sql += ' AND p.brand_id = ?';
      params.push(options.brandId);
    }
    if (options?.keyword) {
      sql += ' AND p.name LIKE ?';
      params.push(`%${options.keyword}%`);
    }
    sql += ' ORDER BY p.sort_order ASC';
    return db.prepare(sql).all(...params) as Product[];
  },

  findPaginated(page = 1, pageSize = 20): { data: Product[]; total: number } {
    const total = (db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number }).count;
    const data = db.prepare('SELECT * FROM products ORDER BY sort_order ASC LIMIT ? OFFSET ?').all(pageSize, (page - 1) * pageSize) as Product[];
    return { data, total };
  },

  update(id: string, data: Partial<Product>): Product | undefined {
    const fields: string[] = [];
    const values: any[] = [];
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined && key !== 'id' && key !== 'created_at') {
        fields.push(`${key} = ?`);
        values.push(value);
      }
    }
    if (fields.length > 0) {
      values.push(id);
      db.prepare(`UPDATE products SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    }
    return this.findById(id);
  },

  delete(id: string): boolean {
    const result = db.prepare('DELETE FROM products WHERE id = ?').run(id);
    return result.changes > 0;
  },
};
